#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "websockets-evlib_uv" for configuration "None"
set_property(TARGET websockets-evlib_uv APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(websockets-evlib_uv PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwebsockets-evlib_uv.so"
  IMPORTED_SONAME_NONE "libwebsockets-evlib_uv.so"
  )

list(APPEND _cmake_import_check_targets websockets-evlib_uv )
list(APPEND _cmake_import_check_files_for_websockets-evlib_uv "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwebsockets-evlib_uv.so" )

# Import target "websockets-evlib_glib" for configuration "None"
set_property(TARGET websockets-evlib_glib APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(websockets-evlib_glib PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwebsockets-evlib_glib.so"
  IMPORTED_SONAME_NONE "libwebsockets-evlib_glib.so"
  )

list(APPEND _cmake_import_check_targets websockets-evlib_glib )
list(APPEND _cmake_import_check_files_for_websockets-evlib_glib "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwebsockets-evlib_glib.so" )

# Import target "websockets-evlib_ev" for configuration "None"
set_property(TARGET websockets-evlib_ev APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(websockets-evlib_ev PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwebsockets-evlib_ev.so"
  IMPORTED_SONAME_NONE "libwebsockets-evlib_ev.so"
  )

list(APPEND _cmake_import_check_targets websockets-evlib_ev )
list(APPEND _cmake_import_check_files_for_websockets-evlib_ev "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwebsockets-evlib_ev.so" )

# Import target "websockets" for configuration "None"
set_property(TARGET websockets APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(websockets PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NONE "C"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwebsockets.a"
  )

list(APPEND _cmake_import_check_targets websockets )
list(APPEND _cmake_import_check_files_for_websockets "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwebsockets.a" )

# Import target "websockets_shared" for configuration "None"
set_property(TARGET websockets_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(websockets_shared PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwebsockets.so.19"
  IMPORTED_SONAME_NONE "libwebsockets.so.19"
  )

list(APPEND _cmake_import_check_targets websockets_shared )
list(APPEND _cmake_import_check_files_for_websockets_shared "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwebsockets.so.19" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
